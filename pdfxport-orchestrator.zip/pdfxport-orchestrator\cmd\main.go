package main

import (
	"log"
	"sync"
	"time"

	"pdfxport-orchestrator/internal/client"
	"pdfxport-orchestrator/internal/engine"
	"pdfxport-orchestrator/internal/queue"
	"pdfxport-orchestrator/internal/storage"
)

func main() {

	log.Println("🚀 Starting orchestrator")

	// =========================
	// CLIENT
	// =========================

	c := client.New(
		"https://sievalhub.sieval.com",
		"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6Ijc1NjQiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9naXZlbm5hbWUiOiJTb2ZpZW4iLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9zdXJuYW1lIjoiQ1BUIiwiZW1wbG95ZWVEZXZpY2UiOiIyZjEyM2JlNS05OWYyLTQ4YWEtOTZmMS1mYjczZGE1MWRlZTEiLCJlbXBsb3llZVR5cGUiOiIwIiwibGljZW5zZWVJZCI6IjEyOTkiLCJ1c2VySWQiOiI0MDciLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9oYXNoIjoiMTRGMTg5QUYiLCJleHAiOjE3NzgxNzczNzcsImlzcyI6Imh0dHA6Ly9zaWV2YWxodWIuc2lldmFsLmNvbS8iLCJhdWQiOiJodHRwOi8vc2lldmFsaHViLnNpZXZhbC5jb20vIn0.bZp0rSVrGGYFmmzwVYBmMoBQruQWH0zY0YzR7QWIofU",
	)

	// =========================
	// STORAGE
	// =========================

	store := storage.New("./output")

	// =========================
	// SQLITE QUEUE
	// =========================

	q := queue.New("./jobs.db")

	// =========================
	// SAMPLE JOBS
	// =========================

	q.Add(
		212117,
		38,
		[]int{578409, 578410, 578411},
		"fr",
	)

	q.Add(
		212117,
		38,
		[]int{578409},
		"fr",
	)

	// =========================
	// HANDLER
	// =========================

	handler := engine.Handler(
		c,
		store,
		q,
	)

	// =========================
	// WORKER LIMITER
	// =========================

	workerPool := make(chan struct{}, 5)

	// =========================
	// MAIN LOOP
	// =========================

	for {

		jobs, err := q.FetchBatch(5)

		if err != nil {

			log.Println("❌ DB error:", err)

			time.Sleep(2 * time.Second)

			continue
		}

		if len(jobs) == 0 {

			log.Println("✅ No more jobs. Exiting.")

			break
		}

		var wg sync.WaitGroup

		for _, job := range jobs {

			wg.Add(1)

			go func(j queue.Job) {

				defer wg.Done()

				workerPool <- struct{}{}

				log.Printf(
					"👷 Worker → Job %d\n",
					j.ID,
				)

				handler(j)

				<-workerPool

			}(job)
		}

		wg.Wait()
	}

	log.Println("🏁 Orchestrator finished")
}
