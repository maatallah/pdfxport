package storage

import (
	"fmt"
	"os"
)

type Store struct {
	Base string
}

func New(base string) *Store {
	os.MkdirAll(base, 0755)
	return &Store{Base: base}
}

func (s *Store) Save(jobID int, data []byte) (string, error) {
	path := fmt.Sprintf("%s/job_%d.pdf", s.Base, jobID)
	return path, os.WriteFile(path, data, 0644)
}
