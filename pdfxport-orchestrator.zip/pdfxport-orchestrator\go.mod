module pdfxport-orchestrator

go 1.26.2

require github.com/mattn/go-sqlite3 v1.14.44
